		<div id="footer">
			<div id="footerNewsletter">
				<img src="/sites/all/themes/storibookweddings/images/h3Newsletter.gif"/>
				<span class="description">Sign up to receive special offers and promotions from Oxygen.</span>
				<form action="http://oxygen.com/newsletter/" method="get" name="form5">
					<span class="email">
					<input id="newsletterSignup" type="text" name="email_address"/>
					</span>
					<span class="join">
					<button id="newsletterJoin" type="submit">Join</button>
					</span>
				</form>
			</div>
			<div id="footerNavigation">
				<img src="/sites/all/themes/storibookweddings/images/h3Navigation.gif"/>
				<span><a href="http://oxygen.com">Home</a></span>
				<span><a href="http://oxygen.com/tvshows/">TV Shows</a></span>
				<span><a href="http://oxygen.com/schedule/">Schedule</a></span>
				<span><a href="http://oxygen.com/sweepstakes/">Sweepstakes</a></span>
				<span><a href="http://o2.oxygen.com">Video</a></span>
				<span><a href="http://oxygen.com/movies/">Movies</a></span>
				<span><a href="http://oxygen.com/mobile/">Mobile</a></span>
				<span><a href="http://oxygen.com/games/">Games</a></span>
				<span><a href="http://forums.oxygen.com/">Community</a></span><br/>
			</div>
			<div id="footerRight">
				<a target="_blank" class="nbcUniversal" href="http://www.nbcuni.com/"><img src="/sites/all/themes/storibookweddings/images/nbcUniversal.gif" alt="NBC Universal"/></a>
				<div id="nbcuPanel">
					<a target="_blank" href="http://nbc.researchresults.com/?s=64">Join the NBCU Panel</a>
				</div>
			</div>
		</div>
		<div id="globalSubFooter">
			<span>TM & Copyright &copy; 1998-2011 Oxygen Media. All Rights Reserved</span>
			<a href="http://oxygen.com/legal/terms.aspx">Terms of Use</a> | <a href="http://oxygen.com/legal/privacyPolicy.aspx">Privacy Policy</a> | <a target="_blank" href="http://www.nbcuni.com/">Corporate Info</a> | <a href="http://oxygen.com/legal/contact.aspx">Contact Us</a>
		</div>
	</div>
</div>
<div id="block-oxygen_omniture-0" class="png block-oxygen_omniture">
	<script language='javascript' type='text/javascript' src='http://www.oxygen.com/js/omniture/s_wrapper.js'></script>
	<!-- SiteCatalyst code version: H.2. Copyright 1997-2008 Omniture, Inc. and NBCU More info available at http://www.omniture.com -->
	<script type='text/javascript' language='javascript'>
<!-- 
s.prop2="Reality";
s.prop3="Photo";
s.prop4="sTORIbook Weddings : Photos : Meet the Wedding Planners";
s.prop5="Season 1";
s.prop10="Tori & Dean: sTORIbook Weddings";
s.pageName=document.title;		//// page name, auto reads from the page TITLE tag
/************* DO NOT ALTER ANYTHING BELOW THIS LINE ! **************/
 var s_code=s.t(); if(s_code) document.write(s_code)
//-->
	</script>
	<script type='text/javascript' language='javascript'>
<!--
if(navigator.appVersion.indexOf('MSIE') >= 0) document.write(unescape('%3C')+'\!-'+'-')
//-->
	</script>
	<!--/DO NOT REMOVE/-->
	<!-- End SiteCatalyst code version: H.2. -->
</div>
<!-- start Vibrant Media IntelliTXT script section -->
<!-- end Vibrant Media IntelliTXT script section -->
<!-- Kontera ContentLink(TM);-->
<script type='text/javascript'>
var dc_AdLinkColor = 'blue' ;
var dc_isBoldActive= 'no';
var dc_PublisherID = 136535 ;
</script>
<script type='text/javascript' src='http://kona.kontera.com/javascript/lib/KonaLibInline.js'>
</script>
<!-- Kontera ContentLink(TM) -->
<script src="http://www.nbcudigitaladops.com/hosted/global.js"></script>
</body>
</html>