<?php
include "Image.php";

$a = new Image("./ugc/wedding-9.jpg");

var_dump($a);

